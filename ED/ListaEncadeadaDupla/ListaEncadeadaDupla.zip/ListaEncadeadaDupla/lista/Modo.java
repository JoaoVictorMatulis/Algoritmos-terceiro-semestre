package ListaEncadeadaDupla.lista;

public enum Modo {
    DIREITA, ESQUERDA;
}

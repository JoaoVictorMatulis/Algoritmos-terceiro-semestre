 

package lista;

/*
 *
 * Professor Gerson Risso
 */
public enum Modo {
    ESQUERDADIREITA, DIREITAESQUERDA;
}

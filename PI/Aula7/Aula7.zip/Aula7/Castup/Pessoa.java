package Aula7.Castup;

public class Pessoa {

    public Pessoa() {
    }

    public void imprimir() {
        System.out.println("Dentro da classe Pessoa");
    }
}

package Aula7.Castup;

public class Funcionario extends Pessoa {
    public void imprimir() {
        System.out.println("Dentro da classe funcionario");
    }
}

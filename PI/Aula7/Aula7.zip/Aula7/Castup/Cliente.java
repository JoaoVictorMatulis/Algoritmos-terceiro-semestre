package Aula7.Castup;

public class Cliente extends Pessoa {

    public Cliente() {
    }

    public void imprimir() {
        System.out.println("Dentro da classe cliente");
    }

}

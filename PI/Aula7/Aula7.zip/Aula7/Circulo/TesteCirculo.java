package Aula7.Circulo;

public class TesteCirculo {
    public static void main(String[] args){
        Circulo circulo = new Circulo();
        circulo.setRaio(10);
        System.out.println(circulo.getRaio());
    }
}

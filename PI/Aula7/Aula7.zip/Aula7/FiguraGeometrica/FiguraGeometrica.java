package Aula7.FiguraGeometrica;

public class FiguraGeometrica {
    protected double area;

    public void calcularArea(){
        
    }
}

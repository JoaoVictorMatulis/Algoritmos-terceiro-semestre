package Aula6.Bicho;

public class Cachorro extends Bicho{
    public void fala(){
        System.out.println("Au au");
    }
}

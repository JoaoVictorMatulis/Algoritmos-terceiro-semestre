package Aula6.Bicho;

public class Bicho {
    public void fala(){
    }
}
